# 智能图书馆管理系统

## 项目简介
这是一个基于FastAPI和Vue.js的智能图书馆管理系统，集成了OpenAI API来提供智能推荐和问答功能。

## 环境要求
- Python 3.8+
- Node.js 14+
- OpenAI API密钥

## 环境配置

### 1. 后端配置
1. 创建并激活虚拟环境：
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
.\venv\Scripts\activate  # Windows
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

3. 配置环境变量：
创建 `.env` 文件并添加以下配置：
```
OPENAI_API_KEY=your_openai_api_key_here
HOST=127.0.0.1
PORT=8001
FRONTEND_PORT=8081
```

### 2. 前端配置
1. 进入前端目录：
```bash
cd frontend
```

2. 启动开发服务器：
```bash
python -m http.server 8081
```

## 启动服务

### 1. 启动后端服务
```bash
cd smart-library
uvicorn main:app --reload --port 8001
```

### 2. 启动前端服务
```bash
cd frontend
python -m http.server 8081
```

## 访问系统
- 前端界面：http://localhost:8081
- API文档：http://localhost:8001/docs

## 主要功能
1. 图书管理
   - 图书列表展示
   - 图书借阅
   - 图书归还
   - 图书搜索

2. 用户管理
   - 用户列表
   - 用户借阅历史
   - 用户信息管理

3. 智能推荐
   - 基于用户兴趣的图书推荐
   - 基于借阅历史的个性化推荐

4. 智能问答
   - 图书相关咨询
   - 借阅规则查询
   - 智能客服

## 技术栈
- 后端：FastAPI, Python
- 前端：Vue.js, HTML5, CSS3
- AI：OpenAI API
- 数据库：SQLite（可选）

## 注意事项
1. 确保已正确配置OpenAI API密钥
2. 保持后端和前端服务同时运行
3. 如遇到端口占用问题，可在.env文件中修改端口配置

## 贡献指南

欢迎提交 Pull Request 和 Issue。在提交之前，请：
1. 确保代码符合项目规范
2. 添加适当的测试
3. 更新相关文档

## 许可证

MIT License 