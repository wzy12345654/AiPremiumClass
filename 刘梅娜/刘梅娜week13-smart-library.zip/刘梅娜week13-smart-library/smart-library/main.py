from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
import requests
from dotenv import load_dotenv
from openai import OpenAI

# 加载环境变量
load_dotenv()

app = FastAPI(title="智能图书管理系统")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 在生产环境中应该设置为具体的域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 数据模型
class Book(BaseModel):
    id: int  # 书籍的id
    title: str  # 书籍的标题
    author: str  # 书籍的作者
    genre: str  # 书籍的类型
    status: str = "available"  # available 或 borrowed

class User(BaseModel):
    # 用户ID
    id: int
    # 用户名
    name: str
    # 用户偏好
    preferences: List[str]
    # 借阅的书籍ID列表
    borrowed_books: List[int] = []

class BorrowReturn(BaseModel):
    # 用户ID
    user_id: int
    # 图书ID
    book_id: int

# 模拟数据库
books = [
    Book(id=1, title="三体", author="刘慈欣", genre="科幻"),
    Book(id=2, title="活着", author="余华", genre="当代文学"),
    Book(id=3, title="百年孤独", author="加西亚·马尔克斯", genre="魔幻现实主义"),
]

users = [
    User(id=1, name="张三", preferences=["科幻", "奇幻"]),
    User(id=2, name="李四", preferences=["历史", "传记"]),
]

# API路由
@app.get("/")
# 定义一个函数，用于读取根目录
def read_root():
    # 返回一个字典，包含欢迎信息、版本号、文档地址、API文档地址以及API接口地址
    return {
        "message": "欢迎使用智能图书管理系统",
        "version": "1.0.0",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "endpoints": {
            "借阅图书": "/books/borrow",
            "归还图书": "/books/return",
            "获取推荐": "/books/recommend/{user_id}",
            "查看所有图书": "/books",
            "查看所有用户": "/users"
        }
    }

@app.get("/books")
def get_books():
    return {"books": books}

@app.get("/users")
def get_users():
    return {"users": users}

@app.post("/books/borrow")
def borrow_book(borrow_data: BorrowReturn):
    # 查找图书
    book = next((b for b in books if b.id == borrow_data.book_id), None)
    if not book:
        raise HTTPException(status_code=404, detail="图书不存在")
    if book.status == "borrowed":
        raise HTTPException(status_code=400, detail="图书已被借出")
    
    # 查找用户
    user = next((u for u in users if u.id == borrow_data.user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    # 更新状态
    book.status = "borrowed"
    user.borrowed_books.append(book.id)
    return {"message": "借阅成功"}

@app.post("/books/return")
def return_book(return_data: BorrowReturn):
    # 查找图书
    book = next((b for b in books if b.id == return_data.book_id), None)
    if not book:
        raise HTTPException(status_code=404, detail="图书不存在")
    if book.status == "available":
        raise HTTPException(status_code=400, detail="图书未被借出")
    
    # 查找用户
    user = next((u for u in users if u.id == return_data.user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    if book.id not in user.borrowed_books:
        raise HTTPException(status_code=400, detail="此书不是由该用户借出")
    
    # 更新状态
    book.status = "available"
    user.borrowed_books.remove(book.id)
    return {"message": "归还成功"}

@app.post("/books/recommend/{user_id}")
async def recommend_books(user_id: int):
    # 查找用户
    user = next((u for u in users if u.id == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    # 获取用户偏好
    preferences = ", ".join(user.preferences)
    
    # 使用Ollama进行推荐
    ollama_recommendations = []
    try:
        ollama_response = requests.post(
            f"{os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')}/api/generate",
            json={
                "model": "llama2",
                "prompt": f"根据用户喜好：{preferences}，推荐5本适合的书籍。只返回书名，每行一本。",
                "stream": False
            }
        )
        if ollama_response.status_code == 200:
            response_data = ollama_response.json()
            if "response" in response_data:
                ollama_recommendations = [
                    book.strip() 
                    for book in response_data["response"].split("\n") 
                    if book.strip()
                ]
    except Exception as e:
        print(f"Ollama API error: {e}")
        # 如果Ollama API失败，使用基于用户偏好的简单推荐
        ollama_recommendations = [
            book.title for book in books 
            if any(pref.lower() in book.genre.lower() for pref in user.preferences)
        ][:5]
    
    # 使用OpenAI进行推荐
    openai_recommendations = []
    try:
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "你是一个图书推荐专家。"
                },
                {
                    "role": "user",
                    "content": f"根据用户喜好：{preferences}，推荐5本适合的书籍。只返回书名，每行一本。"
                }
            ]
        )
        openai_recommendations = [
            book.strip() 
            for book in completion.choices[0].message.content.split("\n") 
            if book.strip()
        ]
    except Exception as e:
        print(f"OpenAI API error: {e}")
        # 如果OpenAI API失败，使用基于用户借阅历史的推荐
        user_books = [book for book in books if book.id in user.borrowed_books]
        if user_books:
            # 基于用户已借阅书籍的类型推荐相似书籍
            borrowed_genres = set(book.genre for book in user_books)
            openai_recommendations = [
                book.title for book in books 
                if book.genre in borrowed_genres and book.id not in user.borrowed_books
            ][:5]
        else:
            # 如果没有借阅历史，使用基于用户偏好的推荐
            openai_recommendations = [
                book.title for book in books 
                if any(pref.lower() in book.genre.lower() for pref in user.preferences)
            ][:5]
    
    return {
        "ollama_recommendations": ollama_recommendations,
        "openai_recommendations": openai_recommendations
    } 